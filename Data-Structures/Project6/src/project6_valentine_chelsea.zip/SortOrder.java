/**
 * Enumerator used to decide on sort order of Collision objects. 
 * @author Joanna K. 
 *
 */
enum SortOrder { ZIP, CYCLISTS, PERSONS} 
